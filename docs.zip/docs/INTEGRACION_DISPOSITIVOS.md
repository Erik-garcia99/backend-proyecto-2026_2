# Dispositivos: despliegue y prueba

## Activación

### Nombres de gateways

Ejecutar también `backend-proyecto-2026_2/scripts/migrate_gateway_names.sql` en el SQL Editor de Supabase antes de desplegar esta actualización. Asigna nombres persistentes `Gateway-1`, `Gateway-2`, etc. a los equipos existentes y un nombre automático a los nuevos. La numeración es global y puede tener saltos; no depende de la posición en la lista. Se puede repetir la migración sin reemplazar nombres editados.

Panel → Dispositivos → seleccionar gateway muestra su estado, edición de nombre y únicamente sus nodos asociados. “Mis nodos” permite consultar todos los de la sucursal. Los nombres visibles se guardan en `gateway.display_name`; el identificador de comunicación y el hostname conservan su función técnica. Actualizar backend y frontend; este cambio no requiere firmware nuevo.

1. Aplicar `backend-proyecto-2026_2/scripts/migrate_devices.sql` a PostgreSQL antes de desplegar el backend. Agrega `esp32_node.location` y `led_guide_point.name` sin borrar datos.
2. Desplegar el backend actualizado con un solo worker: el hub WSS y las búsquedas viven en memoria.
3. Actualizar el servicio de la RPI desde `firmware_RPI_SelfIQ-26-2/SelfIQ_RPI` y reiniciarlo. Debe mantener su configuración Wi-Fi, identidad y token. Requiere `paho-mqtt>=2,<3`, además de `requirements.txt` (el instalador ya lo instala).
4. Recargar el frontend con `EXPO_PUBLIC_API_URL` apuntando al backend actualizado.
5. El ESP32 de prueba usa ahora `NODE_TYPE "guide"`. La RPI también acepta el alias antiguo `shelf_guide`, por lo que ese cambio no obliga a reflashear para registrar un nodo nuevo.

## Flujo

En Panel → Agregar dispositivo, se consultan `/gateways` y se filtran por la sucursal de la sesión. Una RPI puede estar enviando telemetría por HTTP y tener el canal WSS desconectado: el estado de la app corresponde a WSS, que es el canal necesario para las órdenes.

Actualización: Panel abre **Dispositivos**, con selector de las sucursales autorizadas (también para cuentas sin `branch_id`), lista de Raspberry y acceso a Mis dispositivos. Se muestran todos los nodos persistidos, incluso los registrados antes de tener nombre/ubicación. Los errores HTTP se muestran para distinguir una lista vacía de un backend no actualizado o un error de permisos.

La RPI configurada no abre automáticamente el emparejamiento al terminar Wi-Fi. `tcp.enable` abre una ventana fija de 120 segundos; las solicitudes de los ESP32 no la extienden. El AP de recuperación puede abrirse por pérdida de Wi-Fi, pero no distribuye credenciales ni habilita TCP de emparejamiento sin una orden explícita. El backend rechaza MAC nuevas si no hay una búsqueda activa para esa Raspberry y sucursal; los nodos ya registrados pueden reconectarse.

Iniciar búsqueda manda `tcp.enable` y exige `ok: true`. Los ESP32 completan AP/TCP, se conectan al broker y solicitan registro MQTT. La RPI firma el alta REST; los nodos sin nombre/código aparecen como candidatos. Confirmar guarda nombre y ubicación. La búsqueda solicita `tcp.disable` al caducar (120 segundos), incluso sin consultas desde la app. Si la RPI está desconectada o en recuperación, aplica su temporizador local de AP.

Mis dispositivos permite editar nombre/ubicación y eliminar el registro. La guía permite consultar estantes existentes, asignar hasta diez canales y editar sus nombres y estantes. Repetir un alta de luz con idénticos datos conserva el mismo registro.

Los resultados de búsqueda exigen una solicitud de registro recibida desde que empezó esa búsqueda (`last_heartbeat_at >= started_at`), además de no tener nombre/código. Los registros antiguos no son evidencia de un nodo encontrado ahora. Un nodo que ya tiene identidad NVS debe consultarse en Mis nodos; al reconectar no necesariamente vuelve a solicitar registro.

## Alcance del firmware básico

- `light.test` publica por MQTT con QoS 1 y espera confirmación del broker. **No confirma encendido físico**: el ESP32 básico aún no ejecuta GPIO de luces. La interfaz lo indica.
- La conexión de un nodo no se deduce de que esté registrado. Sin una comunicación reciente, se muestra estado desconocido.
- Eliminar desde la app envía `node.reset` y espera confirmación del propio nodo antes de borrar su fila. Conserva Wi-Fi, broker y firmware. Algunas relaciones históricas quedan sin nodo y otras se borran según las claves foráneas existentes; InfluxDB no se borra.
- Las lecturas del detalle nuevo se consultan en `occupancy_snapshot` y `environment_reading` de PostgreSQL. Si las mediciones solo existen en InfluxDB, ese detalle no las mostrará; los endpoints de telemetría de sucursal existentes continúan siendo independientes.
- Registro y edición de cámaras comparten el flujo; configurar imagen sigue pendiente.

## Verificación local

- Backend: 50 pruebas pasan (incluyen confirmación de eliminación, permisos y caducidad sin polling).
- Contrato frontend: pasa. Lint: sin errores, con advertencias de imports/hooks de las pantallas.
- `tsc --noEmit` no dispone de `tsconfig.json` en este proyecto JavaScript; no se considera validación de tipos completada.
- Python: compilación sintáctica correcta. Se reparó un error previo de indentación y el bloque perdido de creación de FastAPI en la RPI.
- Suite RPI: bloqueada por tests antiguos que crean `Config()` sin los campos ahora obligatorios, además de errores derivados. Falta validación con la RPI/ESP32 físicos y PostgreSQL desplegado.

## Eliminar y volver a agregar un nodo

Actualizar backend, frontend, servicio del gateway y el firmware del ESP32 antes de probar. Este cambio no requiere otra migración SQL. El firmware antiguo no ejecuta `node.reset`: el backend conservará el registro si no recibe confirmación.

1. Compilar y flashear `firmware_ESP32-shelf_guide_SelfIQ-26-2/firmware_aforo_shelf_guide` con ESP-IDF (`idf.py build`, `idf.py -p PUERTO flash monitor`). No ejecutar `erase-flash`: el flasheo normal permite conservar NVS con el mismo esquema de particiones.
2. Con nodo y gateway conectados, eliminar el nodo desde la app.
3. El gateway publica en `selfiq/{branch_id}/{node_id}/control/command`, QoS 1, sin retain. El tópico identifica al nodo; el payload lleva solo dos bytes: comando y destino NVS. No usa la trama TCP.
4. Petición `01 03`: `MQTT_REQ_ERASE_NVS=0x01`, `MQTT_NVS_IDENTITY=0x03`. El ESP32 borra `mac`, `node_id` y `branch_id` de `selfiq_node` y confirma con `nvs_commit`. Respuesta en `.../control/result`: `81 03 00` (éxito) o `81 03 01` (error NVS). Los destinos `MQTT_NVS_WIFI=1` y `MQTT_NVS_TCP=2` están reservados; este firmware solo ejecuta el borrado remoto de identidad. Los valores se definen en `mqtt_lib.h` y `selfiq/node_control.py`.
5. El gateway espera hasta 20 segundos la respuesta del nodo. La confirmación del broker por sí sola no autoriza borrar la fila. Si falla, la app muestra el error y permite reintentar.
6. Abrir **Agregar nodo → Iniciar búsqueda**. El ESP32 conserva Wi-Fi y solicita registro periódicamente, sin repetir AP/TCP. Tras eliminar la fila, el backend solo admite esa nueva alta durante una búsqueda. La respuesta anterior con el UUID eliminado se ignora.

Para recuperar una confirmación perdida, NVS conserva temporalmente `reset_topic`, el tópico de control anterior. Este marcador no habilita telemetría ni restaura la identidad y sobrevive a reinicios. Se elimina al guardar una identidad nueva; permite repetir la eliminación si falló la respuesta MQTT o el borrado en PostgreSQL. La cola de telemetría pendiente en RAM del nodo se descarta al restablecerlo.

El comando no usa JSON, cJSON, HEADER, LEN ni TYPE/ACTION de TCP. Valida comando y destino antes de ejecutar. El gateway permite un solo borrado pendiente por nodo y verifica tópico, destino y resultado. Los reintentos sobre la misma identidad son idempotentes; el nuevo registro obtiene otro UUID y otro tópico.

Verificación de esta función: firmware compilado con ESP-IDF 6.0.2; pruebas del gateway cubren payloads binarios, mensajes inválidos, confirmación del nodo, falta de respuesta, exclusión de borrados concurrentes y rechazo de respuestas retained/de otro tópico/otro destino NVS. Pendiente la prueba física de eliminar y volver a agregar.
